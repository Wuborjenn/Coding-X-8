<?php
if(isset($_GET['vkey'])){
    //開始認證
    $vkey = $_GET['vkey'];
    $mysqli = NEW MySQLi('localhost','root','123456','userregistration');
    $resultSet = $mysqli->query("SELECT verified,vkey FROM usertable WHERE verified = 0 AND vkey='$vkey'LIMIT 1");

    if($resultSet->num_rows==1){
        //認證email
        $update=$mysqli->query("UPDATE usertable SET verified = 1 WHERE vkey='$vkey' LIMIT 1");
        if(update){
            echo"您的帳號成功通過認證，可以進行登入了";
        }else{
            echo $mysqli->error;
        }
    }else{
        echo "此帳號為無效帳號或已經被認證過了";
    }
}else{
    die("Something went wrong!");
}

