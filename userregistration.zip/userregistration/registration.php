<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'C:/xampp/sendmail/PHPMailer-6.1.3/src/Exception.php';
require 'C:/xampp/sendmail/PHPMailer-6.1.3/src/PHPMailer.php';
require 'C:/xampp/sendmail/PHPMailer-6.1.3/src/SMTP.php';
session_start();

$con = mysqli_connect('localhost','root','123456','userregistration');

//Connect to the db
mysqli_select_db($con, 'userregistration');


$name=$_POST['user'];
$pass=$_POST['password'];
$pass2=$_POST['repeatedpassword'];
$email=$_POST['email'];

//Generate Vkey
$vkey=md5(time().$name);


//Avoiding repeating username
$s="select * from usertable where name = '$name'";

$result=mysqli_query($con,$s);

$num=mysqli_num_rows($result);

//Situations
if($num==1){
    echo"用戶名稱已經被使用";
}elseif(strlen($name)<3){
    echo"用戶名稱最少為三個字母";
}elseif($pass!=$pass2){
    echo"兩個密碼不符合";
}else{
    //Insert account into db
    $reg= "insert into usertable(name,password,repeatedpassword,email,vkey) values ('$name','$pass','$pass2','$email','$vkey')";
    mysqli_query($con,$reg);
    echo"Registration Successful";

    //Send email
    $mail = new PHPMailer(true);
     
    try {
        //Server settings
        // 產生 Debug 訊息
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        
        $mail->isSMTP();
     
        // SMTP 伺服器的設定，以及驗證資訊  
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        // 底下也可以使用 PHPMailer::ENCRYPTION_SMTPS
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
     
        // SMTP 驗證的使用者資訊
        $mail->Username = 'forigbot001@gmail.com';
        $mail->Password = 'likems520';
     
        // 信件內容的編碼方式，這在範例中沒有，但若不加中文會有問題       
        $mail->CharSet = "utf-8";
        $mail->Encoding = "base64";
     
        // 寄信者與收信者
        $mail->setFrom('gatogathertogether@gmail.com', 'xxx');
        $mail->addAddress($email, 'xxx');
        
        // 其他收信者(可不加名稱), 回信地址, CC副本, BCC 密件副本
        //$mail->addAddress('xxx@example.com');
        //$mail->addReplyTo('xxx@example', 'xxx');
        //$mail->addCC('cc@example.com');
        //$mail->addBCC('bcc@example.com');
     
        // 附件
        //$mail->addAttachment('/var/tmp/file.tar.gz');
        //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');
     
        // 信件內容
        $mail->isHTML(true); // 若是純文字的信，此處用 false
        $mail->Subject = 'GaTo信箱認證';
        $mail->Body = '<h1>歡迎註冊GaTo組隊媒合平台</h1>';
        $mail->Body = "<a href='localhost/userregistration/verify.php?vkey=$vkey'>註冊帳號</a>";
     
        $mail->send();
        echo '送出成功';
        header('location:thankyou.php');
    } catch (Exception $e) {
        echo "送出失敗: {$mail->ErrorInfo}";
    }



}
?>